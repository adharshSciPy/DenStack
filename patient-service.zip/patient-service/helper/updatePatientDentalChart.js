// Helper function to update patient's dental chart
import mongoose from "mongoose";

export const updatePatientDentalChart = async (patientId, dentalWork, visitId, doctorId, treatmentPlanId = null, session) => {
  const Patient = mongoose.model("Patient");
  const patient = await Patient.findById(patientId).session(session);
  
  if (!patient) {
    throw new Error("Patient not found");
  }
  
  // Check if this is for treatment plan creation (status will be "planned")
  const isTreatmentPlanCreation = dentalWork.some(item => 
    item.procedures && item.procedures[0]?.status === "planned"
  );
  
  console.log("🦷 Updating dental chart:", {
    patientId,
    isTreatmentPlanCreation,
    teethCount: dentalWork.length,
    visitId,
    treatmentPlanId
  });
  
  for (const toothWork of dentalWork) {
    const { toothNumber, conditions = [], surfaceConditions = [], procedures = [] } = toothWork;
    
    // Find existing tooth record in dental chart
    let toothRecord = patient.dentalChart.find(
      t => t.toothNumber === toothNumber
    );
    
    if (!toothRecord) {
      // Create new tooth record
      toothRecord = {
        toothNumber,
        conditions: [],
        surfaceConditions: [],
        procedures: [],
        lastUpdated: new Date()
      };
      patient.dentalChart.push(toothRecord);
      console.log(`✅ Created new tooth record for tooth ${toothNumber}`);
    } else {
      console.log(`📝 Found existing tooth record for tooth ${toothNumber}`);
    }
    
    // Update conditions (append unique ones)
    conditions.forEach(condition => {
      if (!toothRecord.conditions.includes(condition)) {
        toothRecord.conditions.push(condition);
      }
    });
    
    // Update surface conditions
    for (const surfaceCondition of surfaceConditions) {
      const existingSurface = toothRecord.surfaceConditions.find(
        sc => sc.surface === surfaceCondition.surface
      );
      
      if (existingSurface) {
        // Add unique conditions to existing surface
        surfaceCondition.conditions.forEach(condition => {
          if (!existingSurface.conditions.includes(condition)) {
            existingSurface.conditions.push(condition);
          }
        });
      } else {
        // Add new surface condition
        toothRecord.surfaceConditions.push({
          surface: surfaceCondition.surface,
          conditions: [...surfaceCondition.conditions]
        });
      }
    }
    
    // Add procedures
    for (const procedure of procedures) {
      // Check if similar procedure already exists
      // Only check for duplicates if it's the same status and visit
      const existingProcedure = toothRecord.procedures.find(p =>
        p.name === procedure.name &&
        p.surface === procedure.surface &&
        p.status === procedure.status &&
        ((procedure.status === "planned" && p.treatmentPlanId?.toString() === treatmentPlanId?.toString()) ||
         (procedure.status === "completed" && p.visitId?.toString() === visitId?.toString()))
      );
      
      if (!existingProcedure) {
        // For planned procedures from treatment plan, we need to ensure they're added
        // For completed procedures, check if a planned version exists and update it
        if (procedure.status === "completed") {
          // Look for a planned version of this procedure from the same treatment plan
          const plannedVersionIndex = toothRecord.procedures.findIndex(p =>
            p.name === procedure.name &&
            p.surface === procedure.surface &&
            p.status === "planned" &&
            p.treatmentPlanId?.toString() === treatmentPlanId?.toString()
          );
          
          if (plannedVersionIndex >= 0) {
            // Update the planned procedure to completed
            toothRecord.procedures[plannedVersionIndex].status = "completed";
            toothRecord.procedures[plannedVersionIndex].performedBy = doctorId;
            toothRecord.procedures[plannedVersionIndex].performedAt = procedure.performedAt || new Date();
            toothRecord.procedures[plannedVersionIndex].visitId = visitId;
            toothRecord.procedures[plannedVersionIndex].cost = procedure.cost || 0;
            toothRecord.procedures[plannedVersionIndex].notes = procedure.notes || "";
            console.log(`✅ Updated planned procedure ${procedure.name} to completed for tooth ${toothNumber}`);
          } else {
            // Add as new completed procedure
            toothRecord.procedures.push({
              name: procedure.name,
              surface: procedure.surface,
              status: "completed",
              cost: procedure.cost || 0,
              notes: procedure.notes || "",
              performedBy: doctorId,
              performedAt: procedure.performedAt || new Date(),
              visitId: visitId,
              treatmentPlanId: treatmentPlanId
            });
            console.log(`✅ Added new completed procedure ${procedure.name} for tooth ${toothNumber}`);
          }
        } else if (procedure.status === "planned") {
          // Add planned procedure
          toothRecord.procedures.push({
            name: procedure.name,
            surface: procedure.surface,
            status: "planned",
            estimatedCost: procedure.estimatedCost || 0,
            notes: procedure.notes || "",
            treatmentPlanId: treatmentPlanId,
            // For planned procedures, these fields will be populated when completed
            performedBy: null,
            performedAt: null,
            visitId: null,
            cost: 0
          });
          console.log(`📋 Added planned procedure ${procedure.name} for tooth ${toothNumber}`);
        }
      } else {
        console.log(`⏭️ Skipping duplicate procedure ${procedure.name} for tooth ${toothNumber}`);
      }
    }
    
    toothRecord.lastUpdated = new Date();
  }
  
  await patient.save({ session });
  console.log("✅ Dental chart updated successfully");
  return patient;
};
